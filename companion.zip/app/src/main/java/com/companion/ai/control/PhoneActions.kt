package com.companion.ai.control

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager

class PhoneActions(private val ctx: Context) {

    private fun launch(i: Intent): Boolean = try {
        // The accessibility service may start activities from the background; a plain context may not.
        val c: Context = PhoneControlService.instance ?: ctx
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    fun openApp(name: String): Boolean {
        val pm = ctx.packageManager
        val match = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true) &&
                pm.getLaunchIntentForPackage(it.packageName) != null
        } ?: return false
        val intent = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        return launch(intent)
    }

    fun call(number: String) = launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))

    fun sendSms(number: String, text: String): Boolean = try {
        val sms = ctx.getSystemService(SmsManager::class.java)
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(text), null, null)
        true
    } catch (e: Exception) { false }

    fun whatsapp(number: String, text: String): Boolean {
        val clean = number.filter { it.isDigit() }
        val uri = Uri.parse("https://wa.me/$clean?text=${Uri.encode(text)}")
        if (!launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))) return false
        Thread.sleep(2500)
        return PhoneControlService.instance?.clickByText("Send") ?: false
    }

    fun setAlarm(hour: Int, minute: Int, label: String) = launch(
        Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        })

    fun setTimer(seconds: Int, label: String) = launch(
        Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        })

    fun flashlight(on: Boolean): Boolean = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(cm.cameraIdList.first(), on); true
    } catch (e: Exception) { false }

    fun toggleWifi(): Boolean {
        launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        Thread.sleep(1200)
        return PhoneControlService.instance?.clickByText("Wi-Fi") ?: false
    }

    fun toggleBluetooth(): Boolean {
        launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        Thread.sleep(1200)
        return PhoneControlService.instance?.clickByText("Bluetooth") ?: false
    }

    fun webSearch(query: String) = launch(
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")))
}
