# Zoya 5.0 Android source

1. Upload the extracted project contents to the root of your GitHub repository (including `.github/workflows/build.yml`).
2. Open **Actions → Build Zoya APK → Run workflow**.
3. Download the `zoya-5.0-build` artifact after the workflow succeeds.
4. Install `app-debug.apk` only after checking signing compatibility with the APK already on your phone.

Gemini API keys are entered inside Zoya's Settings screen. Do not commit keys to GitHub.

For stable in-place updates, configure the same Android keystore used by the installed APK as GitHub Actions secrets. See `ZOYA_5_RELEASE_NOTES.txt` for exact secret names and platform limitations.
