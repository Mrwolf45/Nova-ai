package com.companion.ai.control

import org.json.JSONObject

class ConfirmationGate {
    val sensitive = setOf("send_sms", "send_whatsapp", "make_call")

    data class Pending(val tool: String, val args: JSONObject, val summary: String)

    @Volatile var pending: Pending? = null
        private set

    fun park(tool: String, args: JSONObject, summary: String) { pending = Pending(tool, args, summary) }
    fun release(): Pending? = pending.also { pending = null }
    fun cancel() { pending = null }
}
