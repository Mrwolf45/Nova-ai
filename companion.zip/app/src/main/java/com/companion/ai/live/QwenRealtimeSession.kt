package com.companion.ai.live

import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** QwenCloud Singapore realtime WebSocket adapter. */
class QwenRealtimeSession(
    private val apiKey: String,
    private val systemPrompt: String,
    private val geminiTools: JSONArray,
    private val listener: RealtimeSession.Listener
) : RealtimeSession {
    companion object {
        const val MODEL = "qwen3.8-omni-flash-realtime"
        private const val URL = "wss://ap-southeast-1.maas.qwencloudapi.com/api-ws/v1/realtime?model=$MODEL"
    }

    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    @Volatile override var ready = false
        private set
    @Volatile override var dead = false
        private set

    override fun connect() {
        val request = Request.Builder().url(URL).header("Authorization", "Bearer $apiKey").build()
        ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { /* wait for session.created */ }
            override fun onMessage(webSocket: WebSocket, text: String) { handle(text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(bytes.utf8()) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val was = ready; ready = false
                if (!dead) listener.onClosed(this@QwenRealtimeSession, "Qwen connection error: ${t.message ?: "unknown"}" + (response?.let { " (HTTP ${it.code})" } ?: ""), was)
            }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                val was = ready; ready = false
                if (!dead) listener.onClosed(this@QwenRealtimeSession, "Qwen closed ($code): $reason", was)
                webSocket.close(1000, null)
            }
        })
    }

    private fun sessionUpdate(): String {
        val session = JSONObject()
            .put("modalities", JSONArray().put("text").put("audio"))
            .put("instructions", systemPrompt)
            .put("audio", JSONObject()
                .put("input", JSONObject().put("format", JSONObject()
                    .put("type", "pcm").put("sample_rate", 16000).put("sample_format", "s16le")
                    .put("channels", 1).put("packing", "interleaved").put("channel_layout", "mono")))
                .put("output", JSONObject().put("voice", "Tina").put("format", JSONObject()
                    .put("type", "pcm").put("sample_rate", 24000))))
            .put("input_audio_transcription", JSONObject().put("model", "qwen3-asr-flash-realtime"))
            .put("turn_detection", JSONObject().put("type", "semantic_vad_ec").put("threshold", 0.5).put("silence_duration_ms", 800))
            .put("tools", toQwenTools(geminiTools))
        return JSONObject().put("type", "session.update").put("session", session).toString()
    }

    private fun toQwenTools(source: JSONArray): JSONArray {
        val out = JSONArray()
        for (i in 0 until source.length()) {
            val item = source.optJSONObject(i) ?: continue
            val fn = JSONObject().put("name", item.optString("name")).put("description", item.optString("description"))
            item.optJSONObject("parameters")?.let { fn.put("parameters", normalizeSchema(it)) }
            out.put(JSONObject().put("type", "function").put("function", fn))
        }
        return out
    }

    private fun normalizeSchema(source: JSONObject): JSONObject {
        val out = JSONObject()
        val keys = source.keys()
        while (keys.hasNext()) {
            val key = keys.next(); val value = source.opt(key)
            when (value) {
                is JSONObject -> out.put(key, normalizeSchema(value))
                is JSONArray -> {
                    val arr = JSONArray()
                    for (i in 0 until value.length()) {
                        val v = value.opt(i)
                        arr.put(if (v is JSONObject) normalizeSchema(v) else v)
                    }
                    out.put(key, arr)
                }
                is String -> out.put(key, if (key == "type") value.lowercase() else value)
                else -> out.put(key, value)
            }
        }
        return out
    }

    private fun handle(raw: String) {
        if (dead) return
        try {
            val event = JSONObject(raw)
            when (event.optString("type")) {
                "session.created" -> ws?.send(sessionUpdate())
                "session.updated" -> { ready = true; listener.onReady(this) }
                "input_audio_buffer.speech_started" -> listener.onInterrupted()
                "conversation.item.input_audio_transcription.completed" -> listener.onTranscript(true, event.optString("transcript"))
                "response.audio_transcript.delta", "response.text.delta" -> listener.onTranscript(false, event.optString("delta"))
                "response.audio.delta" -> {
                    val encoded = event.optString("delta")
                    if (encoded.isNotBlank()) listener.onAudio(Base64.decode(encoded, Base64.DEFAULT))
                }
                "response.function_call_arguments.done" -> {
                    val id = event.optString("call_id")
                    val name = event.optString("name")
                    val args = try { JSONObject(event.optString("arguments", "{}")) } catch (_: Exception) { JSONObject() }
                    if (id.isNotBlank() && name.isNotBlank()) listener.onToolCall(id, name, args)
                }
                "response.done" -> listener.onTurnComplete()
                "error" -> {
                    val err = event.optJSONObject("error")
                    val was = ready; ready = false
                    listener.onClosed(this, "Qwen API error: ${err?.optString("message") ?: event}", was)
                }
            }
        } catch (_: Exception) { /* Ignore malformed events; connection callback handles transport errors. */ }
    }

    override fun sendAudio(pcm: ByteArray) {
        if (!ready || dead) return
        ws?.send(JSONObject().put("type", "input_audio_buffer.append").put("audio", Base64.encodeToString(pcm, Base64.NO_WRAP)).toString())
    }

    override fun sendImage(jpeg: ByteArray) {
        if (!ready || dead || jpeg.size > 190 * 1024) return
        ws?.send(JSONObject().put("type", "input_image_buffer.append").put("image", Base64.encodeToString(jpeg, Base64.NO_WRAP)).toString())
    }

    override fun sendText(text: String) {
        if (!ready || dead) return
        val content = JSONArray().put(JSONObject().put("type", "input_text").put("text", text))
        val item = JSONObject().put("type", "message").put("role", "user").put("content", content)
        ws?.send(JSONObject().put("type", "conversation.item.create").put("item", item).toString())
        ws?.send(JSONObject().put("type", "response.create").toString())
    }

    override fun sendToolResult(id: String, name: String, result: String) {
        if (!ready || dead) return
        val item = JSONObject().put("type", "function_call_output").put("call_id", id).put("output", result)
        ws?.send(JSONObject().put("type", "conversation.item.create").put("item", item).toString())
        ws?.send(JSONObject().put("type", "response.create").toString())
    }

    override fun close() {
        dead = true; ready = false
        try { ws?.close(1000, "bye") } catch (_: Exception) { }
        client.dispatcher.executorService.shutdown()
    }
}
