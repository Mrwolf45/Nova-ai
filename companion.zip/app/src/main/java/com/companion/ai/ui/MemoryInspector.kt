package com.companion.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.companion.ai.AppState
import com.companion.ai.CompanionEngine

@Composable
fun MemoryInspector(engine: CompanionEngine) {
    LaunchedEffect(Unit) { engine.refreshMemoryState() }
    var confirmClear by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Zoya ko tumhare baare me ye yaad hai", color = Color.White, fontSize = 16.sp)
            Text("Sab kuch sirf tumhare phone me hai. Kisi ko hata sakte ho.", color = Muted, fontSize = 11.sp)
        }
        if (AppState.memories.isEmpty()) {
            item { Text("Abhi kuch yaad nahi. Baat karo, wo khud yaad rakhegi.", color = Muted, fontSize = 13.sp) }
        }
        items(AppState.memories, key = { it.id }) { m ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PanelBg).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(m.fact, color = Color(0xFFE6E6F0), fontSize = 13.sp)
                    Text(m.category, color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = { engine.db.delete(m.id); engine.refreshMemoryState() }) { Text("Hata") }
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            Text("Pichli baat-cheet", color = Color.White, fontSize = 16.sp)
        }
        items(AppState.chats, key = { "c" + it.id }) { c ->
            val who = if (c.role == "user") "Tum" else "Zoya"
            Text("$who: ${c.text}", color = if (c.role == "user") Color(0xFFCFCFE0) else moodColor(AppState.mood), fontSize = 12.sp)
        }
        item {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("Sab kuch bhool jao") }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Sab memory delete?") },
            text = { Text("Saari yaadein aur baat-cheet hamesha ke liye hat jayengi.") },
            confirmButton = { TextButton(onClick = { engine.db.clearAll(); engine.refreshMemoryState(); confirmClear = false }) { Text("Haan, delete") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Nahi") } }
        )
    }
}
