package com.companion.ai

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import com.companion.ai.memory.Chat
import com.companion.ai.memory.Mem

object AppState {
    var status by mutableStateOf("Tap karke baat shuru karo")
    var level by mutableFloatStateOf(0f)
    var running by mutableStateOf(false)
    var pendingSummary by mutableStateOf<String?>(null)
    var mood by mutableStateOf("happy")
    var cameraOn by mutableStateOf(false)
    var frontCamera by mutableStateOf(true)
    var previewOn by mutableStateOf(true)
    var proactiveOn by mutableStateOf(false)
    var active by mutableStateOf(false)
    var screen by mutableIntStateOf(0)
    var tick by mutableIntStateOf(0)
    val memories = mutableStateListOf<Mem>()
    val chats = mutableStateListOf<Chat>()
    val logs = mutableStateListOf<String>()

    private val main = Handler(Looper.getMainLooper())
    fun log(s: String) {
        main.post {
            logs.add(s.take(300))
            while (logs.size > 6) logs.removeAt(0)
        }
    }
}
