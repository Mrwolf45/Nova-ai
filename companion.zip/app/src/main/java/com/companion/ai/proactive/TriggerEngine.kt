package com.companion.ai.proactive

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.companion.ai.AppState
import com.companion.ai.CompanionEngine
import java.util.Calendar

/**
 * Decides when the companion should start talking on her own.
 * Triggers: time-of-day check-ins, long silence, low battery, new messages, camera expressions.
 * Safety rails: quiet hours (23:00-07:00), 20 min cooldown, max 8 nudges per day, off unless the user enables it.
 */
class TriggerEngine(private val ctx: Context, private val engine: CompanionEngine) {
    private val main = Handler(Looper.getMainLooper())
    private var started = false

    private var lastNudge = 0L
    private var nudgeDay = -1
    private var nudgeCount = 0
    private val slotsDone = HashSet<String>()
    private var lowFired = false

    private var lastFaceSeen = 0L
    private var lastSmileEvent = 0L
    private var lastSleepyEvent = 0L
    private var eyesClosedFrames = 0

    companion object {
        private const val TICK_MS = 30_000L
        private const val COOLDOWN_MS = 20 * 60_000L
        private const val MAX_PER_DAY = 8
        private const val IDLE_CLOSE_MS = 5 * 60_000L
        private const val LONG_SILENCE_MS = 3 * 3600_000L
    }

    private val tick = object : Runnable {
        override fun run() {
            try { check() } catch (_: Exception) { }
            if (started) main.postDelayed(this, TICK_MS)
        }
    }

    private val battery = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return
            val pct = level * 100 / scale
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (charging || pct > 35) { lowFired = false; return }
            if (pct <= 20 && !lowFired && allowed()) {
                lowFired = true
                fire("The phone battery is at $pct% and not charging. Gently tell the user and suggest charging.")
            }
        }
    }

    fun start() {
        if (started) return
        started = true
        ContextCompat.registerReceiver(ctx, battery, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        main.postDelayed(tick, TICK_MS)
    }

    fun stop() {
        started = false
        main.removeCallbacks(tick)
        try { ctx.unregisterReceiver(battery) } catch (_: Exception) { }
    }

    private fun hour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun allowed(): Boolean {
        if (!AppState.proactiveOn || !AppState.active || AppState.running) return false
        val h = hour()
        if (h >= 23 || h < 7) return false
        val now = System.currentTimeMillis()
        if (now - lastNudge < COOLDOWN_MS) return false
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        if (day != nudgeDay) { nudgeDay = day; nudgeCount = 0 }
        return nudgeCount < MAX_PER_DAY
    }

    private fun fire(instruction: String) {
        lastNudge = System.currentTimeMillis()
        nudgeCount++
        engine.proactive(instruction)
    }

    private fun check() {
        val now = System.currentTimeMillis()
        // Close forgotten sessions to save quota
        if (AppState.running && now - engine.lastVoice > IDLE_CLOSE_MS) { engine.stopIdle(); return }
        if (!allowed()) return

        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val dayKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
        val quiet = now - engine.lastVoice > 45 * 60_000L

        val slot = when (h) {
            in 8..10 -> "morning" to "It is morning. Wish the user good morning warmly and ask how they slept or what the plan for today is."
            in 13..15 -> "afternoon" to "It is afternoon. Casually check in and ask if they have eaten lunch or how the day is going."
            in 20..22 -> "evening" to "It is evening. Ask how their day went, with warmth and a little humor."
            else -> null
        }
        if (slot != null && quiet && slotsDone.add("$dayKey-${slot.first}")) { fire(slot.second); return }

        if (h in 10..22 && now - engine.lastVoice > LONG_SILENCE_MS) {
            fire("The user has not talked to you for hours. Casually check in like a friend who misses them, or share something fun or curious.")
        }
    }

    /** Called when a new message notification arrives (app name and sender only, never the message text). */
    fun onNotification(app: String, sender: String) {
        main.post {
            if (!allowed()) return@post
            fire("A new message arrived on $app from $sender. Briefly tell the user and ask if they want you to read it or reply.")
        }
    }

    /** Called about once per second while the camera is on. */
    fun onFace(hasFace: Boolean, smile: Float, eyesOpen: Float) {
        main.post {
            val now = System.currentTimeMillis()
            if (!hasFace) { eyesClosedFrames = 0; return@post }
            val absentFor = now - lastFaceSeen
            lastFaceSeen = now
            eyesClosedFrames = if (eyesOpen < 0.25f) eyesClosedFrames + 1 else 0

            if (AppState.running) {
                if (smile > 0.9f && now - lastSmileEvent > 5 * 60_000L) {
                    lastSmileEvent = now
                    engine.note("The user is smiling or laughing right now. React naturally if it fits.")
                }
                if (eyesClosedFrames >= 8 && now - lastSleepyEvent > 30 * 60_000L) {
                    lastSleepyEvent = now
                    engine.note("The user's eyes have been closed for a while; they look sleepy. Gently mention it if it fits.")
                }
                return@post
            }
            if (!allowed()) return@post
            if (absentFor > 30 * 60_000L && lastFaceSeen > 0L) {
                fire("The user just appeared in front of the camera after a long time. Greet them warmly.")
            } else if (smile > 0.9f && now - lastSmileEvent > 30 * 60_000L) {
                lastSmileEvent = now
                fire("You can see the user smiling or laughing on camera. Ask playfully what is making them happy.")
            } else if (eyesClosedFrames >= 8 && now - lastSleepyEvent > 60 * 60_000L) {
                lastSleepyEvent = now
                fire("You can see the user looks sleepy on camera. Gently suggest they rest, with care.")
            }
        }
    }
}
