package com.companion.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.companion.ai.AppState
import com.companion.ai.CompanionEngine
import com.companion.ai.service.CompanionService

val Bg = Color(0xFF100D18)
val PanelBg = Color(0xFF211827)
val Muted = Color(0xFFB9AABD)
val Rose = Color(0xFFFF8DB8)
val Lavender = Color(0xFFB9A4FF)

fun moodColor(m: String): Color = when (m) {
    "playful" -> Color(0xFFFF83B5)
    "calm" -> Color(0xFFB5A6FF)
    "excited" -> Color(0xFFFFB4C8)
    "concerned" -> Color(0xFFB7B1F5)
    "sleepy" -> Color(0xFF9C91BD)
    "caring" -> Color(0xFFFF9FC6)
    else -> Color(0xFFC09BFF)
}

fun granted(a: ComponentActivity, p: String) =
    ContextCompat.checkSelfPermission(a, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun AppRoot(activity: ComponentActivity, engine: CompanionEngine) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Rose, secondary = Lavender, background = Bg, surface = PanelBg, onPrimary = Color(0xFF32172A))) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Z", color = Rose, fontSize = 25.sp, letterSpacing = 1.sp)
                        Text("O Y A", color = Rose, fontSize = 18.sp, letterSpacing = 3.sp)
                        Text(" ♥", color = Lavender, fontSize = 15.sp)
                    }
                    Text("your personal AI companion", color = Muted, fontSize = 10.sp)
                }
                listOf("Home", "Memory", "Settings").forEachIndexed { i, label ->
                    TextButton(onClick = { AppState.screen = i }) {
                        Text(label, color = if (AppState.screen == i) Rose else Muted, fontSize = 11.sp)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (AppState.screen) {
                    0 -> HomeScreen(activity, engine)
                    1 -> MemoryInspector(engine)
                    else -> PermissionSetup(activity)
                }
            }
        }

        AppState.pendingSummary?.let { summary ->
            AlertDialog(
                onDismissRequest = { engine.confirm(false) },
                title = { Text("Confirm karo") },
                text = { Text(summary) },
                confirmButton = { TextButton(onClick = { engine.confirm(true) }) { Text("Haan, karo") } },
                dismissButton = { TextButton(onClick = { engine.confirm(false) }) { Text("Nahi") } }
            )
        }
    }
}

@Composable
fun HomeScreen(activity: ComponentActivity, engine: CompanionEngine) {
    val color = moodColor(AppState.mood)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true || granted(activity, Manifest.permission.RECORD_AUDIO)) engine.start()
        else AppState.status = "Mic permission chahiye, bina iske sun nahi sakti"
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        AppState.cameraOn = ok
        if (!ok) AppState.status = "Camera permission nahi mili"
    }
    val backupVoiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) engine.acceptRecognizedText(spoken)
            else AppState.status = "Voice samajh nahi aayi, dobara try karo"
        }
    }
    val level by animateFloatAsState(AppState.level, tween(90), label = "level")
    val breathe by rememberInfiniteTransition(label = "b").animateFloat(
        0.95f, 1.05f,
        infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "br"
    )

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var expressionPreview by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(AppState.cameraOn, AppState.frontCamera, AppState.previewOn, previewView) {
        if (AppState.cameraOn && granted(activity, Manifest.permission.CAMERA)) {
            engine.camera.bind(activity, if (AppState.previewOn) previewView else null, AppState.frontCamera)
        } else engine.camera.unbind()
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(270.dp)) {
                val c = center
                val r = size.minDimension * 0.43f * breathe * (1f + level * 0.12f)
                drawCircle(Brush.radialGradient(listOf(color.copy(alpha = if (AppState.running) 0.42f else 0.22f), Color.Transparent), c, r * 1.9f), r * 1.9f, c)
                drawCircle(color.copy(alpha = 0.35f), r, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
            }
            val context = LocalContext.current
            val avatarName = when (expressionPreview ?: AppState.mood) {
                "sad", "concerned" -> "zoya_sad"
                "surprised" -> "zoya_surprised"
                "wink", "excited", "playful" -> "zoya_wink"
                "angry" -> "zoya_angry"
                "cute", "sleepy", "calm", "caring" -> "zoya_cute"
                else -> "zoya_happy"
            }
            val avatarRes = remember(avatarName) {
                context.resources.getIdentifier(avatarName, "drawable", context.packageName)
            }
            val fallbackAvatarRes = remember {
                context.resources.getIdentifier("zoya_happy", "drawable", context.packageName)
            }
            Image(
                painter = painterResource(if (avatarRes != 0) avatarRes else fallbackAvatarRes),
                contentDescription = "Zoya ${AppState.mood} expression",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(218.dp).graphicsLayer { scaleX = breathe; scaleY = breathe }
                    .clip(CircleShape).border(3.dp, Brush.linearGradient(listOf(Rose, Lavender, Rose)), CircleShape)
            )
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                color = Color(0xDD211827), shape = RoundedCornerShape(50)
            ) {
                Text(if (AppState.running) "● Zoya is listening" else "♡ Zoya is here", color = Rose, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 6.dp))
            }
            if (AppState.cameraOn && AppState.previewOn) {
                Box(Modifier.align(Alignment.TopEnd).size(width = 100.dp, height = 140.dp).clip(RoundedCornerShape(16.dp)).background(PanelBg)) {
                    AndroidView(
                        factory = { c -> PreviewView(c).also { previewView = it } },
                        onRelease = { previewView = null },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Text("Zoya is ${if (AppState.running) "with you" else "waiting for you"}", color = Rose, fontSize = 15.sp)
        Text(AppState.status, color = Color(0xFFE7DDEB), textAlign = TextAlign.Center, fontSize = 13.sp)
        Text("mood · ${AppState.mood}", color = color, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(Triple("😊", "Happy", "happy"), Triple("🥺", "Sad", "sad"), Triple("😮", "Wow", "surprised"), Triple("😉", "Wink", "wink"), Triple("😠", "Angry", "angry"), Triple("🥰", "Cute", "cute")).forEach { (emoji, label, expression) ->
                Surface(
                    color = if (expressionPreview == expression) Rose.copy(alpha = 0.22f) else PanelBg,
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (expressionPreview == expression) Rose else Lavender.copy(alpha = 0.35f)),
                    modifier = Modifier.clickable { expressionPreview = if (expressionPreview == expression) null else expression }
                ) {
                    Text("$emoji $label", color = Color(0xFFEADDEB), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
                }
            }
        }
        SelectionContainer {
            Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                AppState.logs.takeLast(3).forEach { Text(it, color = Muted, fontSize = 10.sp) }
            }
        }
        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (AppState.cameraOn) AppState.cameraOn = false
                else if (granted(activity, Manifest.permission.CAMERA)) AppState.cameraOn = true
                else camLauncher.launch(Manifest.permission.CAMERA)
            }, modifier = Modifier.weight(1f)) { Text(if (AppState.cameraOn) "Camera ON" else "Camera OFF", fontSize = 12.sp) }
            OutlinedButton(onClick = { AppState.frontCamera = !AppState.frontCamera }, modifier = Modifier.weight(1f)) {
                Text(if (AppState.frontCamera) "Front" else "Back", fontSize = 12.sp)
            }
            OutlinedButton(onClick = { AppState.previewOn = !AppState.previewOn }, modifier = Modifier.weight(1f)) {
                Text(if (AppState.previewOn) "Preview ON" else "Preview OFF", fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (AppState.running) engine.stop()
                else launcher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color(0xFF32172A)),
            shape = RoundedCornerShape(22.dp)
        ) { Text(if (AppState.running) "End conversation" else "Talk to Zoya", fontSize = 16.sp) }

        OutlinedButton(
            onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Zoya ko bolo...")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                try {
                    backupVoiceLauncher.launch(intent)
                } catch (_: Exception) {
                    AppState.status = "Is phone par system voice recognition available nahi hai"
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 5.dp),
            shape = RoundedCornerShape(18.dp)
        ) { Text("🎙 Backup Voice Input · Urdu", fontSize = 13.sp) }

        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Background companion", color = Color(0xFFEADDEB), fontSize = 13.sp)
                Text("Foreground service · screen-off support while active", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = AppState.active, onCheckedChange = { on ->
                if (on) {
                    if (granted(activity, Manifest.permission.RECORD_AUDIO)) CompanionService.start(activity)
                    else AppState.status = "Pehle Setup me Mic permission do"
                } else CompanionService.stop(activity)
            })
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Proactive check-ins", color = Color(0xFFEADDEB), fontSize = 13.sp)
                Text("Subah/shaam check-in, low battery, naye message. Raat 11 se subah 7 tak chup", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = AppState.proactiveOn, onCheckedChange = { on ->
                engine.setProactive(on)
                if (on && !AppState.active && granted(activity, Manifest.permission.RECORD_AUDIO)) CompanionService.start(activity)
            })
        }
    }
}
