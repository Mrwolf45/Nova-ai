package com.companion.ai.hybrid

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.runBlocking

/** Text-mode hybrid brain. Gemini Live voice remains available as before. */
class HybridAi(private val context: Context) {
    private val prefs = context.getSharedPreferences("hybrid_ai", Context.MODE_PRIVATE)
    private val http = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()
    private var localEngine: Engine? = null
    private var localConversation: Conversation? = null
    private var loadedPath: String? = null

    fun saveOnline(endpoint: String, model: String, key: String) {
        prefs.edit().putString("endpoint", endpoint.trim())
            .putString("model", model.trim()).putString("api_key", key.trim()).apply()
    }
    fun endpoint() = prefs.getString("endpoint", "https://api.groq.com/openai/v1/chat/completions") ?: ""
    fun model() = prefs.getString("model", "llama-3.3-70b-versatile") ?: ""
    fun hasOnlineKey() = !prefs.getString("api_key", "").isNullOrBlank()
    fun apiKey() = prefs.getString("api_key", "") ?: ""
    fun localPath() = prefs.getString("local_model_path", "") ?: ""
    fun setLocalPath(path: String) { prefs.edit().putString("local_model_path", path).apply(); closeLocal() }

    fun isOnlineAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun reply(userText: String, systemPrompt: String, mode: String): Pair<String, String> {
        val useOnline = when (mode) {
            "online" -> true
            "offline" -> false
            else -> isOnlineAvailable() && hasOnlineKey()
        }
        return if (useOnline) {
            try { onlineReply(userText, systemPrompt) to "Online · ${model()}" }
            catch (e: Exception) {
                if (mode == "online") throw e
                localReply(userText, systemPrompt) to "Offline · local fallback"
            }
        } else localReply(userText, systemPrompt) to "Offline · local model"
    }

    private fun onlineReply(userText: String, systemPrompt: String): String {
        val key = prefs.getString("api_key", "")?.trim().orEmpty()
        require(key.isNotBlank()) { "Llama API key Settings mein add karo." }
        val url = endpoint()
        require(url.startsWith("https://")) { "API endpoint HTTPS hona chahiye." }
        val body = JSONObject().put("model", model()).put("temperature", 0.8)
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
                .put(JSONObject().put("role", "user").put("content", userText))).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(url).header("Authorization", "Bearer $key")
            .post(body).build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Llama API ${response.code}: ${raw.take(240)}")
            return JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content").ifBlank { "Jawab nahi mila." }
        }
    }

    private fun localReply(userText: String, systemPrompt: String): String {
        val path = localPath()
        require(path.isNotBlank() && File(path).exists()) {
            "Offline model install nahi. Settings mein compatible .litertlm model select karo."
        }
        return runBlocking {
            synchronized(this@HybridAi) {
                if (loadedPath != path || localConversation == null) {
                    closeLocal()
                    val engine = Engine(EngineConfig(modelPath = path))
                    engine.initialize()
                    localEngine = engine
                    localConversation = engine.createConversation(
                        ConversationConfig(systemInstruction = Contents.of(systemPrompt))
                    )
                    loadedPath = path
                }
                localConversation!!.sendMessage(userText).text.ifBlank { "Local model ne jawab nahi diya." }
            }
        }
    }

    @Synchronized fun closeLocal() {
        try { localConversation?.close() } catch (_: Exception) {}
        try { localEngine?.close() } catch (_: Exception) {}
        localConversation = null; localEngine = null; loadedPath = null
    }
}
