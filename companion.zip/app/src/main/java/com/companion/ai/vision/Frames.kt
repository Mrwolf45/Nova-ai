package com.companion.ai.vision

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

object Frames {
    fun toJpeg(src: Bitmap, maxDim: Int, quality: Int): ByteArray {
        val longest = maxOf(src.width, src.height)
        val bmp = if (longest > maxDim) {
            val s = maxDim.toFloat() / longest
            Bitmap.createScaledBitmap(src, (src.width * s).toInt().coerceAtLeast(1), (src.height * s).toInt().coerceAtLeast(1), true)
        } else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return out.toByteArray()
    }
}
