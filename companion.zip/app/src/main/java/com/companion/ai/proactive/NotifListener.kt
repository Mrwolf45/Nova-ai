package com.companion.ai.proactive

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.companion.ai.CompanionApp

/** Only passes along "new message from X on <app>". Message text is never read or stored. */
class NotifListener : NotificationListenerService() {
    private val messaging = listOf("whatsapp", "telegram", "messaging", "mms", "orca", "sms")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName || sbn.isOngoing) return
            val n = sbn.notification
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            if (messaging.none { sbn.packageName.contains(it, ignoreCase = true) }) return
            val pm = packageManager
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (_: Exception) { "an app" }
            val sender = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "someone"
            CompanionApp.instance.engine.triggers.onNotification(app, sender)
        } catch (_: Exception) { }
    }
}
