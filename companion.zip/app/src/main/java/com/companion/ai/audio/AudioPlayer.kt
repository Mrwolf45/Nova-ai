package com.companion.ai.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.LinkedBlockingQueue

/** Plays 24 kHz PCM from Gemini. flush() drops everything instantly when the user interrupts. */
class AudioPlayer(private val onLevel: (Float) -> Unit) {
    private val queue = LinkedBlockingQueue<ByteArray>()
    @Volatile private var running = false
    private var track: AudioTrack? = null

    fun start() {
        if (running) return
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track = t
        running = true
        t.play()
        Thread {
            while (running) {
                val data = queue.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS)
                if (data == null) { onLevel(0f); continue }
                onLevel(AudioCapture.rms(data, data.size))
                t.write(data, 0, data.size)
            }
        }.apply { isDaemon = true }.start()
    }

    fun enqueue(pcm: ByteArray) { queue.offer(pcm) }

    fun isSilent(): Boolean = queue.isEmpty()

    fun flush() {
        queue.clear()
        track?.let { try { it.pause(); it.flush(); it.play() } catch (_: Exception) {} }
        onLevel(0f)
    }

    fun stop() {
        running = false
        queue.clear()
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
    }
}
