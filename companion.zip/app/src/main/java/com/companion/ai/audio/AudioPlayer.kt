package com.companion.ai.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioManager
import android.content.Context
import android.os.Build
import java.util.concurrent.LinkedBlockingQueue

/** Plays 24 kHz PCM from Gemini. flush() drops everything instantly when the user interrupts. */
class AudioPlayer(context: Context, private val onLevel: (Float) -> Unit) {
    private val audioManager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var previousAudioMode: Int? = null
    private var previousSpeakerphoneOn: Boolean? = null
    private var previousCommunicationDevice: android.media.AudioDeviceInfo? = null

    /** Route assistant speech to the phone loudspeaker instead of the quiet earpiece. */
    private fun routeToSpeaker() {
        try {
            previousAudioMode = audioManager.mode
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                previousCommunicationDevice = audioManager.communicationDevice
                val speaker = audioManager.availableCommunicationDevices.firstOrNull {
                    it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                }
                if (speaker != null) audioManager.setCommunicationDevice(speaker)
            } else {
                @Suppress("DEPRECATION")
                run {
                    previousSpeakerphoneOn = audioManager.isSpeakerphoneOn
                    audioManager.isSpeakerphoneOn = true
                }
            }
        } catch (_: Exception) {
            // Keep audio playback available even if a device does not allow route changes.
        }
    }

    private fun restoreAudioRoute() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val previous = previousCommunicationDevice
                if (previous != null) audioManager.setCommunicationDevice(previous)
                else audioManager.clearCommunicationDevice()
            } else {
                @Suppress("DEPRECATION")
                run { audioManager.isSpeakerphoneOn = previousSpeakerphoneOn ?: false }
            }
            previousAudioMode?.let { audioManager.mode = it }
        } catch (_: Exception) {
            try { audioManager.mode = AudioManager.MODE_NORMAL } catch (_: Exception) { }
        } finally {
            previousAudioMode = null
            previousSpeakerphoneOn = null
            previousCommunicationDevice = null
        }
    }
    private val queue = LinkedBlockingQueue<ByteArray>()
    @Volatile private var running = false
    private var track: AudioTrack? = null

    fun start() {
        if (running) return
        routeToSpeaker()
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track = t
        running = true
        t.play()
        Thread {
            while (running) {
                val data = queue.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS)
                if (data == null) { onLevel(0f); continue }
                onLevel(AudioCapture.rms(data, data.size))
                t.write(data, 0, data.size)
            }
        }.apply { isDaemon = true }.start()
    }

    fun enqueue(pcm: ByteArray) { queue.offer(pcm) }

    fun isSilent(): Boolean = queue.isEmpty()

    fun flush() {
        queue.clear()
        track?.let { try { it.pause(); it.flush(); it.play() } catch (_: Exception) {} }
        onLevel(0f)
    }

    fun stop() {
        running = false
        queue.clear()
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
        restoreAudioRoute()
    }
}
