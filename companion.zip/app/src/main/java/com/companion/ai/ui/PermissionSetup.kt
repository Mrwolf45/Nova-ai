package com.companion.ai.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.companion.ai.AppState
import com.companion.ai.CompanionApp
import com.companion.ai.control.PhoneControlService

@Composable
private fun PermRow(title: String, desc: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PanelBg).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(desc, color = Muted, fontSize = 11.sp)
        }
        if (ok) Text("ON", color = Color(0xFF66BB6A), fontSize = 13.sp)
        else Button(onClick = onClick) { Text(action, fontSize = 12.sp) }
    }
}

@Composable
fun PermissionSetup(activity: ComponentActivity) {
    val t = AppState.tick          // re-evaluate when the app returns from Settings
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { AppState.tick++ }
    fun open(i: Intent) { try { activity.startActivity(i) } catch (_: Exception) { } }

    val notifListenerOn = NotificationManagerCompat.getEnabledListenerPackages(activity).contains(activity.packageName)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Setup (ek baar)", color = Color.White, fontSize = 18.sp)
        Text("Sab ON kar do taaki Zoya poori tarah kaam kare. Ye sab sirf is phone par rehta hai.", color = Muted, fontSize = 12.sp)

        PermRow("Microphone", "Sunne ke liye", granted(activity, Manifest.permission.RECORD_AUDIO), "Allow") {
            launcher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
        PermRow("Camera", "Tumhe aur aas-paas dekhne ke liye", granted(activity, Manifest.permission.CAMERA), "Allow") {
            launcher.launch(arrayOf(Manifest.permission.CAMERA))
        }
        PermRow("Call aur SMS", "Call milane aur SMS bhejne ke liye (har baar tumse puchegi)",
            granted(activity, Manifest.permission.CALL_PHONE) && granted(activity, Manifest.permission.SEND_SMS), "Allow") {
            launcher.launch(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            PermRow("Notifications", "Background notification dikhane ke liye", granted(activity, Manifest.permission.POST_NOTIFICATIONS), "Allow") {
                launcher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            }
        }
        PermRow("Phone control (Accessibility)",
            "Apps kholna, tap, type, screen padhna. Settings me 'Companion Phone Control' ko ON karo.",
            PhoneControlService.isRunning, "Kholo") { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        PermRow("Message alerts", "Naye message aane par khud bataye (sirf naam, message nahi padhti)",
            notifListenerOn, "Kholo") { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        PermRow("Battery optimization", "Background me band na ho, isliye 'Unrestricted' / 'Don't optimize' chuno",
            false, "Kholo") { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }

        Text(
            "Agar Accessibility ya Message alerts wala switch grey (band) dikhe: Android sideloaded apps ko roakta hai. " +
            "Phone Settings > Apps > Companion > upar teen dots (⋮) > 'Allow restricted settings' dabao, phir dobara try karo.",
            color = Muted, fontSize = 11.sp
        )
        OutlinedButton(onClick = {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.packageName)))
        }, modifier = Modifier.fillMaxWidth()) { Text("App info kholo") }
        val engine = CompanionApp.instance.engine
        var keyText by remember { mutableStateOf("") }
        var keyCount by remember { mutableStateOf(engine.allKeys().size) }
        Text("Gemini API keys", color = Color.White, fontSize = 16.sp)
        Text("Ek line me ek key paste karo. Ek key ki limit khatam ya error ho to app khud agli key par chali jayegi. " +
            "Keys sirf is phone ke app-private storage me save hoti hain. APK/repository me key bake nahi hoti.", color = Muted, fontSize = 11.sp)
        OutlinedTextField(
            value = keyText, onValueChange = { keyText = it },
            label = { Text("Keys (ek line me ek)") },
            minLines = 3, modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            engine.saveKeys(keyText)
            keyCount = engine.allKeys().size
            keyText = ""
        }, modifier = Modifier.fillMaxWidth()) { Text("Keys save karo") }
        Text("Abhi total keys: $keyCount", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))
    }
}
