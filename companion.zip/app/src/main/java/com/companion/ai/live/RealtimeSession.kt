package com.companion.ai.live

import org.json.JSONObject

/** Provider-neutral contract shared by Gemini Live and Qwen Omni Realtime. */
interface RealtimeSession {
    interface Listener {
        fun onReady(s: RealtimeSession)
        fun onAudio(pcm: ByteArray)
        fun onInterrupted()
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onTranscript(user: Boolean, text: String)
        fun onTurnComplete()
        fun onResumeHandle(handle: String)
        fun onGoAway()
        fun onClosed(s: RealtimeSession, reason: String, wasReady: Boolean)
    }
    val ready: Boolean
    val dead: Boolean
    fun connect()
    fun sendAudio(pcm: ByteArray)
    fun sendImage(jpeg: ByteArray)
    fun sendText(text: String)
    fun sendToolResult(id: String, name: String, result: String)
    fun close()
}
