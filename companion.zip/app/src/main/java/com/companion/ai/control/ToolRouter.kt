package com.companion.ai.control

import org.json.JSONArray
import org.json.JSONObject

class ToolRouter(
    private val actions: PhoneActions,
    private val gate: ConfirmationGate,
    private val memoryTools: (String, JSONObject) -> String
) {
    fun execute(name: String, args: JSONObject): String {
        if (name in gate.sensitive) {
            val d = describe(name, args)
            gate.park(name, args, d)
            return "PENDING_CONFIRMATION: Not executed yet. A confirmation dialog is now on the user's screen. " +
                "Briefly ask the user out loud: \"$d - should I go ahead?\" and tell them to tap Yes on screen."
        }
        return run(name, args)
    }

    fun confirmPending(): String {
        val p = gate.release() ?: return "Nothing pending."
        return run(p.tool, p.args)
    }

    private fun run(name: String, a: JSONObject): String {
        val svc = PhoneControlService.instance
        val ok: Boolean = try {
            when (name) {
                "open_app" -> actions.openApp(a.getString("app_name"))
                "make_call" -> actions.call(a.getString("number"))
                "send_sms" -> actions.sendSms(a.getString("number"), a.getString("text"))
                "send_whatsapp" -> actions.whatsapp(a.getString("number"), a.getString("text"))
                "set_alarm" -> actions.setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", "Alarm"))
                "set_timer" -> actions.setTimer(a.getInt("seconds"), a.optString("label", "Timer"))
                "flashlight" -> actions.flashlight(a.getBoolean("on"))
                "toggle_wifi" -> actions.toggleWifi()
                "toggle_bluetooth" -> actions.toggleBluetooth()
                "web_search" -> actions.webSearch(a.getString("query"))
                "read_screen" -> return svc?.readScreen() ?: "Accessibility service is not enabled."
                "click_text" -> svc?.clickByText(a.getString("text")) ?: false
                "type_text" -> svc?.typeText(a.getString("text")) ?: false
                "scroll" -> svc?.scroll(a.optBoolean("forward", true)) ?: false
                "go_back" -> svc?.back() ?: false
                "go_home" -> svc?.home() ?: false
                "save_memory", "recall_memory", "look_at_screen", "set_camera", "set_mood" -> return memoryTools(name, a)
                else -> return "Unknown tool: $name"
            }
        } catch (e: Exception) {
            return "FAILED: ${e.message}"
        }
        return if (ok) "OK" else "FAILED"
    }

    private fun describe(name: String, a: JSONObject) = when (name) {
        "send_sms" -> "Send SMS to ${a.optString("number")}: \"${a.optString("text")}\""
        "send_whatsapp" -> "Send WhatsApp to ${a.optString("number")}: \"${a.optString("text")}\""
        "make_call" -> "Call ${a.optString("number")}"
        else -> "$name $a"
    }

    companion object {
        private fun fn(
            name: String, desc: String,
            props: Map<String, String> = emptyMap(),
            req: List<String> = props.keys.toList()
        ): JSONObject {
            val o = JSONObject().put("name", name).put("description", desc).put("behavior", "BLOCKING")
            if (props.isNotEmpty()) {
                val p = JSONObject()
                props.forEach { (k, t) -> p.put(k, JSONObject().put("type", t)) }
                o.put("parameters", JSONObject().put("type", "OBJECT").put("properties", p).put("required", JSONArray(req)))
            }
            return o
        }

        val declarations: JSONArray = JSONArray()
            .put(fn("open_app", "Open an installed app by name", mapOf("app_name" to "STRING")))
            .put(fn("make_call", "Call a phone number", mapOf("number" to "STRING")))
            .put(fn("send_sms", "Send an SMS", mapOf("number" to "STRING", "text" to "STRING")))
            .put(fn("send_whatsapp", "Send a WhatsApp message", mapOf("number" to "STRING", "text" to "STRING")))
            .put(fn("set_alarm", "Set an alarm", mapOf("hour" to "INTEGER", "minute" to "INTEGER", "label" to "STRING"), listOf("hour", "minute")))
            .put(fn("set_timer", "Start a countdown timer", mapOf("seconds" to "INTEGER", "label" to "STRING"), listOf("seconds")))
            .put(fn("flashlight", "Turn flashlight on or off", mapOf("on" to "BOOLEAN")))
            .put(fn("toggle_wifi", "Open Wi-Fi panel and toggle"))
            .put(fn("toggle_bluetooth", "Open Bluetooth settings and toggle"))
            .put(fn("web_search", "Search Google", mapOf("query" to "STRING")))
            .put(fn("read_screen", "Read the text currently on the phone screen"))
            .put(fn("click_text", "Tap a UI element by its visible text", mapOf("text" to "STRING")))
            .put(fn("type_text", "Type text into the focused input field", mapOf("text" to "STRING")))
            .put(fn("scroll", "Scroll the current screen", mapOf("forward" to "BOOLEAN"), emptyList()))
            .put(fn("go_back", "Press the Back button"))
            .put(fn("go_home", "Press the Home button"))
            .put(fn("save_memory", "Remember an important fact about the user", mapOf("fact" to "STRING", "category" to "STRING"), listOf("fact")))
            .put(fn("recall_memory", "Search long-term memory", mapOf("query" to "STRING")))
            .put(fn("look_at_screen", "Take a screenshot of the phone screen so you can SEE it"))
            .put(fn("set_camera", "Turn the camera on/off and choose front or back camera", mapOf("on" to "BOOLEAN", "front" to "BOOLEAN"), listOf("on")))
            .put(fn("set_mood", "Update your own current mood: happy, playful, calm, excited, concerned, sleepy, caring", mapOf("mood" to "STRING")))
    }
}
