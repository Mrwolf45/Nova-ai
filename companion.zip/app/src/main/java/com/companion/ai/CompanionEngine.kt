package com.companion.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.companion.ai.audio.AudioCapture
import com.companion.ai.audio.AudioPlayer
import com.companion.ai.control.*
import com.companion.ai.live.LiveSession
import com.companion.ai.memory.MemoryDb
import com.companion.ai.persona.MoodEngine
import com.companion.ai.persona.PersonaPrompt
import com.companion.ai.proactive.TriggerEngine
import com.companion.ai.vision.CameraStreamer
import org.json.JSONObject

/** Central brain: wires mic, speaker, camera, memory, mood, tools, Gemini session and proactive triggers together. */
class CompanionEngine(private val ctx: Context) : LiveSession.Listener {
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val db = MemoryDb(ctx)
    val mood = MoodEngine(ctx)
    private val gate = ConfirmationGate()
    private val router = ToolRouter(PhoneActions(ctx), gate) { n, a -> extraTool(n, a) }
    private val player = AudioPlayer(ctx) { l -> AppState.level = l }
    private val capture = AudioCapture { bytes, level ->
        if (level > 0.25f) lastVoice = System.currentTimeMillis()
        if (player.isSilent()) AppState.level = level
        session?.sendAudio(bytes)
    }
    val camera = CameraStreamer(ctx) { jpeg, hasFace, smile, eyes ->
        if (AppState.running) session?.sendImage(jpeg)
        triggers.onFace(hasFace, smile, eyes)
    }
    val triggers = TriggerEngine(ctx, this)

    @Volatile var lastVoice = System.currentTimeMillis()
    private var session: LiveSession? = null
    private var userStopped = true
    private var attempt = 0
    private var workedOnce = false
    private var resumeHandle: String? = null
    private var pendingInitial: String? = null
    private var reconnectStreak = 0
    private var lastReconnect = 0L

    private val badUntil = HashMap<String, Long>()
    private var currentKey = ""

    private val userBuf = StringBuilder()
    private val aiBuf = StringBuilder()

    init {
        AppState.proactiveOn = prefs.getBoolean("proactive", false)
        AppState.mood = mood.current()
    }

    /** API keys are supplied in Settings and remain in app-private preferences. */
    fun allKeys(): List<String> {
        val saved = prefs.getString("keys", "") ?: ""
        return saved.split(Regex("[\\s,;]+"))
            .map { it.trim() }.filter { it.length >= 20 }.distinct()
    }

    fun saveKeys(text: String) {
        prefs.edit().putString("keys", text).apply()
        badUntil.clear()
    }

    private fun pickKey(): String? {
        val now = System.currentTimeMillis()
        return allKeys().firstOrNull { (badUntil[it] ?: 0L) < now }
    }

    fun setProactive(on: Boolean) {
        AppState.proactiveOn = on
        prefs.edit().putBoolean("proactive", on).apply()
    }

    fun refreshMemoryState() {
        AppState.memories.clear(); AppState.memories.addAll(db.memories())
        AppState.chats.clear(); AppState.chats.addAll(db.recentChats(40))
    }

    // ---------- session lifecycle ----------

    fun start(initialText: String? = null) {
        if (AppState.running) return
        val first = pickKey()
        if (first == null) {
            AppState.status = if (allKeys().isEmpty()) "API key nahi mili. Setup tab me key paste karo"
                              else "Saari keys ki limit/error hai, thodi der baad try karo"
            return
        }
        currentKey = first
        AppState.running = true
        userStopped = false
        attempt = 0
        workedOnce = false
        resumeHandle = null
        pendingInitial = initialText
        reconnectStreak = 0
        lastVoice = System.currentTimeMillis()
        AppState.status = "Connect ho raha hai..."
        player.start()
        connect()
    }

    private fun connect() {
        val memories = db.memories(40).map { it.fact }
        val chats = db.recentChats(12).map { it.role to it.text }
        val prompt = PersonaPrompt.build(memories, chats, mood.current())
        session = LiveSession(
            currentKey, prompt, ToolRouter.declarations,
            lite = attempt >= 1, resumeHandle = resumeHandle, listener = this
        ).also { it.connect() }
    }

    /**
     * Accepts text from Android's built-in speech recognizer as a fallback
     * when the Gemini Live microphone session is unavailable or interrupted.
     */
    fun acceptRecognizedText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        main.post {
            AppState.status = "Backup voice se samajh aaya: $clean"
            if (!AppState.running) {
                start(clean)
            } else if (session?.ready == true) {
                session?.sendText(clean)
            } else {
                pendingInitial = clean
            }
        }
    }

    fun stop() {
        userStopped = true
        stopInternal()
    }

    private fun stopInternal() {
        flushChat()
        AppState.running = false
        capture.stop()
        player.stop()
        session?.close()
        session = null
        AppState.level = 0f
        AppState.pendingSummary = null
    }

    fun stopIdle() {
        stop()
        AppState.status = "Kaafi der se chup tha, session band kar diya. Dobara bulao!"
    }

    // ---------- proactive entry points ----------

    /** Start a conversation by herself. Only called by TriggerEngine. */
    fun proactive(instruction: String) {
        main.post {
            if (AppState.running) return@post
            AppState.status = "Zoya khud baat shuru kar rahi hai..."
            start(
                "[SYSTEM EVENT - not spoken by the user] $instruction " +
                "Start talking to the user right now in 1-2 short, natural sentences, in your own words. " +
                "Never mention this system event."
            )
        }
    }

    fun note(text: String) {
        if (AppState.running) session?.sendText("[SYSTEM NOTE - not spoken by the user] $text")
    }

    // ---------- confirmation ----------

    fun confirm(yes: Boolean) {
        AppState.pendingSummary = null
        Thread {
            val msg = if (yes) "User tapped YES. Result: " + router.confirmPending()
                      else { gate.cancel(); "User tapped NO. Cancelled, don't do it." }
            session?.sendText(msg)
        }.start()
    }

    // ---------- tools that need engine access ----------

    private fun extraTool(name: String, a: JSONObject): String {
        return when (name) {
            "save_memory" -> {
                val ok = db.addMemory(a.getString("fact"), a.optString("category", "general"))
                main.post { refreshMemoryState() }
                if (ok) "Saved" else "Already knew that"
            }
            "recall_memory" -> {
                val hits = db.search(a.optString("query"))
                if (hits.isEmpty()) "Nothing found" else hits.joinToString("\n") { it.fact }
            }
            "look_at_screen" -> {
                val svc = PhoneControlService.instance ?: return "Accessibility service is not enabled."
                val jpeg = svc.screenshotJpeg() ?: return "Could not capture the screen (needs Android 11+, or the screen is protected)."
                session?.sendImage(jpeg)
                "Screenshot sent. Look at it and describe or answer now."
            }
            "set_camera" -> {
                main.post {
                    AppState.cameraOn = a.optBoolean("on", true)
                    if (a.has("front")) AppState.frontCamera = a.optBoolean("front", true)
                }
                "OK. Note: the camera only works while the app is open on screen."
            }
            "set_mood" -> { mood.set(a.optString("mood")); "OK" }
            else -> "Unknown tool"
        }
    }

    // ---------- chat log ----------

    private fun flushChat() {
        if (userBuf.isNotEmpty()) { db.addChat("user", userBuf.toString()); userBuf.setLength(0) }
        if (aiBuf.isNotEmpty()) { db.addChat("ai", aiBuf.toString()); aiBuf.setLength(0) }
    }

    // ---------- LiveSession.Listener ----------

    override fun onReady(s: LiveSession) {
        main.post {
            if (s !== session) return@post
            workedOnce = true
            AppState.status = "Sun rahi hun... bolo!"
            if (!capture.isRunning) capture.start()
            pendingInitial?.let { s.sendText(it); pendingInitial = null }
        }
    }

    override fun onAudio(pcm: ByteArray) {
        lastVoice = System.currentTimeMillis()
        AppState.status = "Bol rahi hun..."
        player.enqueue(pcm)
    }

    override fun onInterrupted() {
        player.flush()
        AppState.status = "Haan bolo, sun rahi hun"
    }

    override fun onTranscript(user: Boolean, text: String) {
        synchronized(userBuf) {
            if (user) {
                if (aiBuf.isNotEmpty()) { db.addChat("ai", aiBuf.toString()); aiBuf.setLength(0) }
                userBuf.append(text)
            } else {
                if (userBuf.isNotEmpty()) { db.addChat("user", userBuf.toString()); userBuf.setLength(0) }
                aiBuf.append(text)
            }
        }
    }

    override fun onTurnComplete() { synchronized(userBuf) { flushChat() } }

    override fun onResumeHandle(handle: String) { resumeHandle = handle }

    override fun onGoAway() { main.post { reconnect("Server ne session refresh kiya") } }

    override fun onToolCall(id: String, name: String, args: JSONObject) {
        Thread {
            val result = try { router.execute(name, args) } catch (e: Exception) { "FAILED: ${e.message}" }
            gate.pending?.let { pending -> main.post { AppState.pendingSummary = pending.summary } }
            session?.sendToolResult(id, name, result)
        }.start()
    }

    override fun onClosed(s: LiveSession, reason: String, wasReady: Boolean) {
        main.post {
            if (s !== session || userStopped) return@post
            AppState.log(reason)

            // A 1008 "session not found or expired" is a stale Live API
            // resumption handle, NOT an invalid API key. Drop the handle and
            // open a brand-new session instead of retrying the dead session.
            val expiredSession = reason.contains("session not found", true) ||
                (reason.contains("session", true) && reason.contains("expired", true)) ||
                (reason.contains("1008") && reason.contains("BidiGenerateContent", true))
            if (expiredSession) {
                // Never reuse a stale resume token after a 1008 Live-session rejection.
                resumeHandle = null
                if (attempt < 2) {
                    attempt++
                    AppState.status = "Purana session reject hua. Fresh session ban raha hai..."
                    reconnect("Fresh session (1008)")
                } else {
                    stopInternal()
                    AppState.status = "Live session reject ho raha hai (1008). Naya session start karke try karo."
                }
                return@post
            }

            val quota = reason.contains("quota", true) || reason.contains("429") || reason.contains("exhaust", true)
            val keyIssue = quota || reason.contains("API key", true) || reason.contains("403") ||
                reason.contains("401") || reason.contains("PERMISSION_DENIED", true)
            if (keyIssue) {
                // this key is bad or out of quota: park it and move to the next one
                badUntil[currentKey] = System.currentTimeMillis() + (if (quota) 60 * 60_000L else 24 * 3600_000L)
                val next = pickKey()
                if (next != null) {
                    currentKey = next
                    val ks = allKeys()
                    AppState.status = "Dusri key try ho rahi hai (${ks.indexOf(next) + 1}/${ks.size})"
                    reconnect(reason)
                } else {
                    stopInternal()
                    AppState.status = "Saari keys fail ya limit par: $reason"
                }
                return@post
            }
            val authIssue = reason.contains("API key", true) || reason.contains("403") || reason.contains("401")
            if (!wasReady && !workedOnce && attempt == 0 && !authIssue) {
                attempt = 1           // retry with the minimal (lite) setup
                reconnect("Simple mode me dobara try")
            } else if (workedOnce) {
                reconnect(reason)
            } else {
                stopInternal()
                AppState.status = "Connect nahi hua: $reason"
            }
        }
    }

    private fun reconnect(why: String) {
        if (userStopped) return
        val now = System.currentTimeMillis()
        reconnectStreak = if (now - lastReconnect < 8000) reconnectStreak + 1 else 0
        lastReconnect = now
        if (reconnectStreak > 4) {
            stopInternal()
            AppState.status = "Connection baar baar toot raha hai: $why"
            return
        }
        AppState.status = "Dobara connect ho raha hai..."
        val old = session
        main.postDelayed({
            if (userStopped) return@postDelayed
            old?.close()
            connect()
        }, 600)
    }
}
