package com.companion.ai.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/** Records 16 kHz mono PCM in 50 ms chunks. Echo cancellation lets you interrupt without the AI hearing itself. */
class AudioCapture(private val onChunk: (ByteArray, Float) -> Unit) {
    @Volatile private var running = false
    val isRunning: Boolean get() = running
    private var rec: AudioRecord? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        val chunk = 1600
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, chunk * 4)
        )
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
        rec = r
        running = true
        r.startRecording()
        Thread {
            val buf = ByteArray(chunk)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf.copyOf(n), rms(buf, n))
            }
        }.apply { isDaemon = true }.start()
    }

    fun stop() {
        running = false
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release()
        rec = null
    }

    companion object {
        fun rms(b: ByteArray, n: Int): Float {
            val sb = ByteBuffer.wrap(b, 0, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            var sum = 0.0
            val cnt = sb.remaining()
            if (cnt == 0) return 0f
            while (sb.hasRemaining()) { val s = sb.get().toDouble(); sum += s * s }
            val level = sqrt(sum / cnt).toFloat() / 6000f
            return sqrt(level.coerceIn(0f, 1f))
        }
    }
}
