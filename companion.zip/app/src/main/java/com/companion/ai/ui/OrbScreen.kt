package com.companion.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.companion.ai.AppState
import com.companion.ai.CompanionEngine
import com.companion.ai.service.CompanionService

val Bg = Color(0xFF05060A)
val PanelBg = Color(0xFF12131A)
val Muted = Color(0xFF9A9AB0)

fun moodColor(m: String): Color = when (m) {
    "playful" -> Color(0xFFFF7EB6)
    "calm" -> Color(0xFF4FC3F7)
    "excited" -> Color(0xFFFFB74D)
    "concerned" -> Color(0xFF9FA8DA)
    "sleepy" -> Color(0xFF7E8AA8)
    "caring" -> Color(0xFFF48FB1)
    else -> Color(0xFF8E7CFF)
}

fun granted(a: ComponentActivity, p: String) =
    ContextCompat.checkSelfPermission(a, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun AppRoot(activity: ComponentActivity, engine: CompanionEngine) {
    MaterialTheme(colorScheme = darkColorScheme(primary = moodColor(AppState.mood), background = Bg, surface = PanelBg)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("Zoya", "Memory", "Setup").forEachIndexed { i, label ->
                    TextButton(onClick = { AppState.screen = i }) {
                        Text(label, color = if (AppState.screen == i) moodColor(AppState.mood) else Muted)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (AppState.screen) {
                    0 -> HomeScreen(activity, engine)
                    1 -> MemoryInspector(engine)
                    else -> PermissionSetup(activity)
                }
            }
        }

        AppState.pendingSummary?.let { summary ->
            AlertDialog(
                onDismissRequest = { engine.confirm(false) },
                title = { Text("Confirm karo") },
                text = { Text(summary) },
                confirmButton = { TextButton(onClick = { engine.confirm(true) }) { Text("Haan, karo") } },
                dismissButton = { TextButton(onClick = { engine.confirm(false) }) { Text("Nahi") } }
            )
        }
    }
}

@Composable
fun HomeScreen(activity: ComponentActivity, engine: CompanionEngine) {
    val color = moodColor(AppState.mood)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true || granted(activity, Manifest.permission.RECORD_AUDIO)) engine.start()
        else AppState.status = "Mic permission chahiye, bina iske sun nahi sakti"
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        AppState.cameraOn = ok
        if (!ok) AppState.status = "Camera permission nahi mili"
    }
    val level by animateFloatAsState(AppState.level, tween(90), label = "level")
    val breathe by rememberInfiniteTransition(label = "b").animateFloat(
        0.95f, 1.05f,
        infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "br"
    )

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    LaunchedEffect(AppState.cameraOn, AppState.frontCamera, AppState.previewOn, previewView) {
        if (AppState.cameraOn && granted(activity, Manifest.permission.CAMERA)) {
            engine.camera.bind(activity, if (AppState.previewOn) previewView else null, AppState.frontCamera)
        } else engine.camera.unbind()
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(280.dp)) {
                val c = center
                val base = size.minDimension / 3.3f
                val alive = if (AppState.running) 1f else 0.5f
                val r = base * breathe * (1f + level * 0.9f)
                drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.40f * alive), Color.Transparent), c, r * 2.1f), r * 2.1f, c)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.85f * alive), color.copy(alpha = alive), color.copy(alpha = 0.35f)), c, r
                    ), r, c
                )
            }
            if (AppState.cameraOn && AppState.previewOn) {
                Box(Modifier.align(Alignment.TopEnd).size(width = 100.dp, height = 140.dp).clip(RoundedCornerShape(16.dp)).background(PanelBg)) {
                    AndroidView(
                        factory = { c -> PreviewView(c).also { previewView = it } },
                        onRelease = { previewView = null },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Text(AppState.status, color = Color(0xFFCFCFE0), textAlign = TextAlign.Center)
        Text("mood: ${AppState.mood}", color = color, fontSize = 12.sp)
        SelectionContainer {
            Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                AppState.logs.takeLast(3).forEach { Text(it, color = Muted, fontSize = 10.sp) }
            }
        }
        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (AppState.cameraOn) AppState.cameraOn = false
                else if (granted(activity, Manifest.permission.CAMERA)) AppState.cameraOn = true
                else camLauncher.launch(Manifest.permission.CAMERA)
            }, modifier = Modifier.weight(1f)) { Text(if (AppState.cameraOn) "Camera ON" else "Camera OFF", fontSize = 12.sp) }
            OutlinedButton(onClick = { AppState.frontCamera = !AppState.frontCamera }, modifier = Modifier.weight(1f)) {
                Text(if (AppState.frontCamera) "Front" else "Back", fontSize = 12.sp)
            }
            OutlinedButton(onClick = { AppState.previewOn = !AppState.previewOn }, modifier = Modifier.weight(1f)) {
                Text(if (AppState.previewOn) "Preview ON" else "Preview OFF", fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (AppState.running) engine.stop()
                else launcher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (AppState.running) "Band karo" else "Baat shuru karo") }

        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Hamesha active (background)", color = Color(0xFFCFCFE0), fontSize = 13.sp)
                Text("Notification dikhegi, app band hone par bhi sunti rahegi", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = AppState.active, onCheckedChange = { on ->
                if (on) {
                    if (granted(activity, Manifest.permission.RECORD_AUDIO)) CompanionService.start(activity)
                    else AppState.status = "Pehle Setup me Mic permission do"
                } else CompanionService.stop(activity)
            })
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Khud se baat kare (proactive)", color = Color(0xFFCFCFE0), fontSize = 13.sp)
                Text("Subah/shaam check-in, low battery, naye message. Raat 11 se subah 7 tak chup", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = AppState.proactiveOn, onCheckedChange = { on ->
                engine.setProactive(on)
                if (on && !AppState.active && granted(activity, Manifest.permission.RECORD_AUDIO)) CompanionService.start(activity)
            })
        }
    }
}
