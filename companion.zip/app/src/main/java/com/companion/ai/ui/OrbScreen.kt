package com.companion.ai.ui

import android.Manifest
import android.content.Intent
import android.speech.RecognizerIntent
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.companion.ai.AppState
import com.companion.ai.CompanionEngine
import com.companion.ai.service.CompanionService

val Bg = Color(0xFF100D18)
val PanelBg = Color(0xFF211827)
val Muted = Color(0xFFB9AABD)
val Rose = Color(0xFFFF8DB8)
val Lavender = Color(0xFFB9A4FF)

fun moodColor(m: String): Color = when (m) {
    "playful" -> Color(0xFFFF83B5)
    "calm" -> Color(0xFFB5A6FF)
    "excited" -> Color(0xFFFFB4C8)
    "concerned" -> Color(0xFFB7B1F5)
    "sleepy" -> Color(0xFF9C91BD)
    "caring" -> Color(0xFFFF9FC6)
    else -> Color(0xFFC09BFF)
}

fun granted(a: ComponentActivity, p: String) =
    ContextCompat.checkSelfPermission(a, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun AppRoot(activity: ComponentActivity, engine: CompanionEngine) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Rose, secondary = Lavender, background = Bg, surface = PanelBg, onPrimary = Color(0xFF32172A))) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Z O Y A  ♥", color = Rose, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("your companion, always close", color = Muted, fontSize = 10.sp)
                }
                Surface(color = if (AppState.running) Rose.copy(alpha = .16f) else PanelBg, shape = CircleShape) {
                    Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(if (AppState.running) Color(0xFF7BE0A1) else Muted, CircleShape))
                        Spacer(Modifier.width(7.dp))
                        Text(if (AppState.running) "LIVE" else "READY", color = if (AppState.running) Color(0xFF9CEBB7) else Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (AppState.screen) {
                    0 -> HomeScreen(activity, engine)
                    1 -> ChatScreen(engine)
                    2 -> ToolsScreen(activity, engine)
                    3 -> PermissionSetup(activity)
                    4 -> MemoryInspector(engine)
                    else -> HomeScreen(activity, engine)
                }
            }
            NavigationBar(containerColor = Color(0xFF19131F), contentColor = Rose, tonalElevation = 0.dp) {
                val tabs = listOf("Home" to "⌂", "Chat" to "✉", "Tools" to "✧", "Setup" to "⚙")
                tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = AppState.screen == index,
                        onClick = { AppState.screen = index },
                        icon = { Text(item.second, fontSize = 19.sp) },
                        label = { Text(item.first, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Rose, selectedTextColor = Rose, indicatorColor = Rose.copy(alpha = .13f), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }
        AppState.pendingSummary?.let { summary ->
            AlertDialog(
                onDismissRequest = { engine.confirm(false) },
                title = { Text("Confirm karo") },
                text = { Text(summary) },
                confirmButton = { TextButton(onClick = { engine.confirm(true) }) { Text("Haan, karo") } },
                dismissButton = { TextButton(onClick = { engine.confirm(false) }) { Text("Nahi") } }
            )
        }
    }
}

@Composable
fun HomeScreen(activity: ComponentActivity, engine: CompanionEngine) {
    val color = moodColor(AppState.mood)
    val level by animateFloatAsState(AppState.level, tween(100), label = "voice-level")
    val breathe by rememberInfiniteTransition(label = "avatar-breathe").animateFloat(
        .985f, 1.025f,
        infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathing"
    )
    val context = LocalContext.current
    val avatarName = when (AppState.mood) {
        "sad", "concerned" -> "zoya_sad"
        "surprised" -> "zoya_surprised"
        "wink", "excited", "playful" -> "zoya_wink"
        "angry" -> "zoya_angry"
        "cute", "sleepy", "calm", "caring" -> "zoya_cute"
        else -> "zoya_happy"
    }
    val avatarRes = remember(avatarName) { context.resources.getIdentifier(avatarName, "drawable", context.packageName) }
    val fallbackAvatar = remember { context.resources.getIdentifier("zoya_happy", "drawable", context.packageName) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) engine.start() else AppState.status = "Mic permission chahiye"
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Spacer(Modifier.height(6.dp))
        Text(if (AppState.running) "I'm here with you" else "A little space, just for us", color = Color(0xFFEADDEB), fontSize = 19.sp, fontWeight = FontWeight.Medium)
        Text("${AppState.mood.replaceFirstChar { it.uppercase() }} mood  ·  ${engine.activeProviderLabel()}", color = color, fontSize = 11.sp)
        Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(292.dp)) {
                val r = size.minDimension * (.37f + level * .045f)
                drawCircle(Brush.radialGradient(listOf(color.copy(alpha = if (AppState.running) .34f else .19f), Color.Transparent), center, r * 1.9f), r * 1.9f, center)
                drawCircle(color.copy(alpha = .16f + level * .18f), r * 1.23f, center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = (2.5f + level * 5f).dp.toPx()))
            }
            Image(
                painter = painterResource(if (avatarRes != 0) avatarRes else fallbackAvatar),
                contentDescription = "Zoya avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(236.dp).graphicsLayer { scaleX = breathe + level * .025f; scaleY = breathe + level * .025f }
                    .clip(CircleShape).border(3.dp, Brush.sweepGradient(listOf(Rose, Lavender, color, Rose)), CircleShape)
            )
            Surface(Modifier.align(Alignment.BottomCenter), color = Color(0xEE211827), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = .5f))) {
                Text(if (AppState.running) "●  Listening & responding" else "♡  Zoya is waiting", color = Rose, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 15.dp, vertical = 8.dp))
            }
        }
        Text(AppState.status, color = Color(0xFFE7DDEB), textAlign = TextAlign.Center, fontSize = 12.sp, maxLines = 2)
        Button(
            onClick = { if (AppState.running) engine.stop() else launcher.launch(Manifest.permission.RECORD_AUDIO) },
            modifier = Modifier.fillMaxWidth().height(58.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color(0xFF32172A)),
            shape = RoundedCornerShape(22.dp)
        ) { Text(if (AppState.running) "■  End conversation" else "♫  Talk to Zoya", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        Text("Your voice is private to this conversation", color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ChatScreen(engine: CompanionEngine) {
    var draft by remember { mutableStateOf("") }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) engine.acceptRecognizedText(spoken)
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Your conversation", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Type or dictate in Urdu / Roman Urdu", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(AppState.logs.toList()) { line ->
                Surface(color = PanelBg, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(line, color = Color(0xFFEADDEB), fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                }
            }
            if (AppState.logs.isEmpty()) item { Text("Abhi conversation shuru nahi hui. Home par ja kar voice start karo ya neeche message bhejo.", color = Muted, fontSize = 13.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("Zoya ko message…") })
            Button(onClick = { val m = draft.trim(); if (m.isNotEmpty()) { engine.acceptRecognizedText(m); draft = "" } }, enabled = draft.isNotBlank()) { Text("Send") }
        }
        OutlinedButton(onClick = {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Zoya se baat karo")
            }
            try { speechLauncher.launch(intent) } catch (_: Exception) { AppState.status = "Speech service available nahi" }
        }, modifier = Modifier.fillMaxWidth()) { Text("🎙 Urdu voice typing (offline pack if installed)") }
    }
}

@Composable
fun ToolsScreen(activity: ComponentActivity, engine: CompanionEngine) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Quick controls", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Phone actions aur companion features yahan rakhe hain, home ko simple rakhne ke liye.", color = Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("WhatsApp", "Open chats") { engine.quickAction("open_whatsapp") }
            ActionTile("Instagram", "Open reels") { engine.quickAction("open_instagram") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("YouTube", "Open videos") { engine.quickAction("open_app", org.json.JSONObject().put("app_name", "YouTube")) }
            ActionTile("Next Reel", "Scroll feed") { engine.quickAction("next_reel") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("Read screen", "Accessibility") { engine.quickAction("read_screen") }
            ActionTile("Memories", "View saved facts") { AppState.screen = 4 }
        }
        Divider(color = Lavender.copy(alpha = .2f))
        Text("Camera", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text("Camera preview and visual understanding work while Zoya is open.", color = Muted, fontSize = 11.sp)
        var previewView by remember { mutableStateOf<PreviewView?>(null) }
        val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> AppState.cameraOn = ok }
        LaunchedEffect(AppState.cameraOn, AppState.frontCamera, AppState.previewOn, previewView) {
            if (AppState.cameraOn && granted(activity, Manifest.permission.CAMERA)) engine.camera.bind(activity, if (AppState.previewOn) previewView else null, AppState.frontCamera)
            else engine.camera.unbind()
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (AppState.cameraOn) AppState.cameraOn = false else if (granted(activity, Manifest.permission.CAMERA)) AppState.cameraOn = true else camLauncher.launch(Manifest.permission.CAMERA) }, modifier = Modifier.weight(1f)) { Text(if (AppState.cameraOn) "Camera ON" else "Camera OFF") }
            OutlinedButton(onClick = { AppState.frontCamera = !AppState.frontCamera }, modifier = Modifier.weight(1f)) { Text(if (AppState.frontCamera) "Front" else "Back") }
        }
        if (AppState.cameraOn) {
            AndroidView(factory = { c -> PreviewView(c).also { previewView = it } }, onRelease = { previewView = null }, modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp)))
        }
        Divider(color = Lavender.copy(alpha = .2f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Background companion", color = Color.White, fontSize = 14.sp)
                Text("Foreground service while active", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = AppState.active, onCheckedChange = { on ->
                if (on) { if (granted(activity, Manifest.permission.RECORD_AUDIO)) CompanionService.start(activity) else AppState.status = "Setup me mic permission do" }
                else CompanionService.stop(activity)
            })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Proactive check-ins", color = Color.White, fontSize = 14.sp)
                Text("Quiet hours: 11 PM – 7 AM", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = AppState.proactiveOn, onCheckedChange = { on -> engine.setProactive(on); if (on && !AppState.active && granted(activity, Manifest.permission.RECORD_AUDIO)) CompanionService.start(activity) })
        }
        Text("Phone automation ke liye Accessibility permission zaroori hai. Protected screens ya call audio ko bypass nahi kiya ja sakta.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun RowScope.ActionTile(title: String, detail: String, onClick: () -> Unit) {
    Surface(color = PanelBg, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Lavender.copy(alpha = .2f)), modifier = Modifier.weight(1f).clickable(onClick = onClick)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Rose, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}
