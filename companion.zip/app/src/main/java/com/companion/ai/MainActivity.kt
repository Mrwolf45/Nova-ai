package com.companion.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.companion.ai.ui.AppRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val engine = (application as CompanionApp).engine
        setContent { AppRoot(this, engine) }
    }

    override fun onResume() {
        super.onResume()
        AppState.tick++   // makes the permission screen re-check its status
    }
}
