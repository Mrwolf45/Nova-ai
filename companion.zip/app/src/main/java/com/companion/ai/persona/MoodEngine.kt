package com.companion.ai.persona

import android.content.Context
import com.companion.ai.AppState
import java.util.Calendar

/** Keeps the companion's current mood. The AI can change it with the set_mood tool; otherwise it follows time of day. */
class MoodEngine(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("mood", Context.MODE_PRIVATE)

    companion object {
        val moods = listOf("happy", "playful", "calm", "excited", "concerned", "sleepy", "caring")
    }

    fun current(): String {
        val m = prefs.getString("mood", null)
        val ts = prefs.getLong("ts", 0L)
        val result = if (m != null && System.currentTimeMillis() - ts < 3 * 3600_000L) m else byTime()
        AppState.mood = result
        return result
    }

    fun set(mood: String) {
        val m = mood.lowercase().trim()
        if (m !in moods) return
        prefs.edit().putString("mood", m).putLong("ts", System.currentTimeMillis()).apply()
        AppState.mood = m
    }

    private fun byTime(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 0..5 -> "sleepy"
            in 6..11 -> "happy"
            in 12..17 -> "playful"
            else -> "calm"
        }
    }
}
