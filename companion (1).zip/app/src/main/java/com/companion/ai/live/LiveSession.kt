package com.companion.ai.live

import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** WebSocket client for the Gemini Live API (full-duplex voice, vision frames, tool calling). */
class LiveSession(
    private val apiKey: String,
    private val systemPrompt: String,
    private val tools: JSONArray,
    private val lite: Boolean,
    private val resumeHandle: String?,
    private val listener: Listener
) {
    interface Listener {
        fun onReady(s: LiveSession)
        fun onAudio(pcm: ByteArray)
        fun onInterrupted()
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onTranscript(user: Boolean, text: String)
        fun onTurnComplete()
        fun onResumeHandle(handle: String)
        fun onGoAway()
        fun onClosed(s: LiveSession, reason: String, wasReady: Boolean)
    }

    companion object {
        // Verified on Nov 2026: gemini-3.8-live is the current GA Live model.
        // Older 3.1 / 2.5 preview Live models were shut down on 17 Nov 2026.
        const val MODEL = "models/gemini-3.8-live"
        const val VOICE = "Aoede"
        private const val URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    @Volatile var ready = false
        private set
    @Volatile var dead = false
        private set

    fun connect() {
        val req = Request.Builder().url("$URL?key=$apiKey").build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setupJson()) }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val was = ready
                ready = false
                if (!dead) listener.onClosed(this@LiveSession,
                    "Connection error: ${t.message ?: "unknown"}" + (response?.let { " (HTTP ${it.code})" } ?: ""), was)
            }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                val was = ready
                ready = false
                webSocket.close(1000, null)
                if (!dead) listener.onClosed(this@LiveSession, "Server closed ($code): $reason", was)
            }
        })
    }

    private fun setupJson(): String {
        val gen = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig",
                JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE))))
        val setup = JSONObject()
            .put("model", MODEL)
            .put("generationConfig", gen)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))
        if (!lite) {
            gen.put("enableAffectiveDialog", true)
            gen.put("mediaResolution", "MEDIA_RESOLUTION_LOW")
            setup.put("inputAudioTranscription", JSONObject())
            setup.put("outputAudioTranscription", JSONObject())
            // Lets audio+video sessions run longer than the default 2 minutes
            setup.put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
            val sr = JSONObject()
            if (!resumeHandle.isNullOrBlank()) sr.put("handle", resumeHandle)
            setup.put("sessionResumption", sr)
        }
        return JSONObject().put("setup", setup).toString()
    }

    private fun handle(text: String) {
        if (dead) return
        try {
            val j = JSONObject(text)
            if (j.has("setupComplete")) { ready = true; listener.onReady(this); return }
            j.optJSONObject("sessionResumptionUpdate")?.let {
                val h = it.optString("newHandle")
                if (h.isNotBlank()) listener.onResumeHandle(h)
            }
            if (j.has("goAway")) listener.onGoAway()
            j.optJSONObject("serverContent")?.let { sc ->
                if (sc.optBoolean("interrupted")) listener.onInterrupted()
                sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                    for (i in 0 until parts.length()) {
                        val inl = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                        listener.onAudio(Base64.decode(inl.getString("data"), Base64.DEFAULT))
                    }
                }
                sc.optJSONObject("inputTranscription")?.optString("text")?.let { if (it.isNotEmpty()) listener.onTranscript(true, it) }
                sc.optJSONObject("outputTranscription")?.optString("text")?.let { if (it.isNotEmpty()) listener.onTranscript(false, it) }
                if (sc.optBoolean("turnComplete")) listener.onTurnComplete()
            }
            j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
                for (i in 0 until calls.length()) {
                    val c = calls.getJSONObject(i)
                    listener.onToolCall(c.optString("id"), c.getString("name"), c.optJSONObject("args") ?: JSONObject())
                }
            }
        } catch (_: Exception) { /* ignore malformed frame */ }
    }

    fun sendAudio(pcm: ByteArray) {
        if (!ready) return
        val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
            .put("data", Base64.encodeToString(pcm, Base64.NO_WRAP))
            .put("mimeType", "audio/pcm;rate=16000")))
        ws?.send(msg.toString())
    }

    /** Camera frames and screenshots (JPEG). Max about 1 per second. */
    fun sendImage(jpeg: ByteArray) {
        if (!ready) return
        val msg = JSONObject().put("realtimeInput", JSONObject().put("video", JSONObject()
            .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
            .put("mimeType", "image/jpeg")))
        ws?.send(msg.toString())
    }

    fun sendText(text: String) {
        if (!ready) return
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", text)).toString())
    }

    fun sendToolResult(id: String, name: String, result: String) {
        val r = JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result))
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(r))).toString())
    }

    fun close() {
        dead = true
        ready = false
        try { ws?.close(1000, "bye") } catch (_: Exception) { }
        client.dispatcher.executorService.shutdown()
    }
}
