ZOYA 4.1 - SOURCE PACKAGE

WHAT IS INCLUDED
- Gemini Live conversational companion (API key entered inside the app)
- Urdu/Roman Urdu companion persona and mood/expression mapping
- Six existing avatar expression images
- On-device SQLite conversation history and editable/deletable memory
- Phone actions through Android intents and optional Accessibility Service
- Confirmation dialog for calls and outgoing SMS/WhatsApp messages
- Optional proactive check-ins with quiet hours, cooldown and daily cap
- Camera/face events while the app is open and camera is enabled
- Android system Urdu speech-recognition fallback (offline preferred)
- GitHub Actions workflow to build a debug APK artifact

BUILD
1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Open Actions > Build Zoya APK > Run workflow, or push to main/master.
3. Download artifact `zoya-4.1-build` after the workflow succeeds.

IMPORTANT LIMITS
- This ZIP is source code, not a prebuilt APK. The workflow must succeed before install.
- Debug signing is not suitable for stable in-place release updates. Use the same persistent
  release keystore for every release that must update an installed copy.
- Android does not guarantee simultaneous microphone access during WhatsApp/SIM calls.
  Zoya cannot inject her audio into the other caller's call stream.
- Offline Urdu speech recognition depends on the phone's installed speech service/language pack.
  Full offline generative conversation is not included; Gemini Live requires internet and a key.
- Accessibility actions depend on user enabling the service and on each app's UI. Protected
  screens and Android security restrictions cannot be bypassed.
- No multi-provider model router, 3D avatar/lip-sync, or self-updater is claimed in this build.
- Proactive voice requires the user to enable it, grant permissions, and keep Android background
  microphone foreground-service rules satisfied.

PRIVACY
API keys entered in Settings are stored in app-private SharedPreferences. Do not put API keys in
public source repositories, screenshots, or shared ZIP files. This is local storage, not a claim
of hardware-backed encryption.
