package com.companion.ai.memory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Mem(val id: Long, val fact: String, val category: String, val ts: Long)
data class Chat(val id: Long, val role: String, val text: String, val ts: Long)

/** Local SQLite memory: long-term facts + conversation history. Everything stays on the phone. */
class MemoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "companion.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, fact TEXT, category TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE chats(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, text TEXT, ts INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized
    fun addMemory(fact: String, category: String): Boolean {
        val exists = readableDatabase.rawQuery(
            "SELECT 1 FROM memories WHERE fact = ? COLLATE NOCASE", arrayOf(fact)
        ).use { it.moveToFirst() }
        if (exists) return false
        val cv = ContentValues().apply {
            put("fact", fact); put("category", category); put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("memories", null, cv)
        return true
    }

    @Synchronized
    fun memories(limit: Int = 200): List<Mem> {
        val out = ArrayList<Mem>()
        readableDatabase.rawQuery(
            "SELECT id, fact, category, ts FROM memories ORDER BY ts DESC LIMIT $limit", null
        ).use { c ->
            while (c.moveToNext()) out.add(Mem(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3)))
        }
        return out
    }

    fun search(query: String): List<Mem> {
        val words = query.lowercase().split(" ").filter { it.length > 2 }
        val all = memories(300)
        if (words.isEmpty()) return all.take(8)
        return all.map { m -> m to words.count { m.fact.lowercase().contains(it) } }
            .filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }.take(8)
    }

    @Synchronized
    fun delete(id: Long) { writableDatabase.delete("memories", "id = ?", arrayOf(id.toString())) }

    @Synchronized
    fun addChat(role: String, text: String) {
        if (text.isBlank()) return
        val cv = ContentValues().apply {
            put("role", role); put("text", text.trim()); put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("chats", null, cv)
    }

    @Synchronized
    fun recentChats(n: Int): List<Chat> {
        val out = ArrayList<Chat>()
        readableDatabase.rawQuery(
            "SELECT id, role, text, ts FROM chats ORDER BY id DESC LIMIT $n", null
        ).use { c ->
            while (c.moveToNext()) out.add(Chat(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3)))
        }
        return out.reversed()
    }

    @Synchronized
    fun clearAll() {
        writableDatabase.delete("memories", null, null)
        writableDatabase.delete("chats", null, null)
    }
}
