package com.companion.ai.control

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.accessibilityservice.GestureDescription
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.WindowManager
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.companion.ai.vision.Frames
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class PhoneControlService : AccessibilityService() {

    companion object {
        @Volatile var instance: PhoneControlService? = null
        val isRunning get() = instance != null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun readScreen(maxChars: Int = 6000): String {
        val root = rootInActiveWindow ?: return "Screen not readable."
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || sb.length > maxChars) return
            val label = n.text ?: n.contentDescription
            if (!label.isNullOrBlank() || n.isClickable || n.isEditable) {
                sb.append("  ".repeat(depth.coerceAtMost(6)))
                sb.append(if (n.isClickable) "[btn] " else if (n.isEditable) "[input] " else "")
                sb.append(label ?: n.viewIdResourceName ?: "").append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().ifBlank { "Screen is empty or protected." }
    }

    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(text)
        for (node in matches) {
            var target: AccessibilityNodeInfo? = node
            while (target != null) {
                if (target.isClickable && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                target = target.parent
            }
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && tap(rect.centerX().toFloat(), rect.centerY().toFloat())) return true
        }
        return false
    }

    /** Tap screen coordinates in normalized 0..1 units. */
    fun tapNormalized(x: Float, y: Float): Boolean {
        val dm = resources.displayMetrics
        return tap((x.coerceIn(0f, 1f) * dm.widthPixels), (y.coerceIn(0f, 1f) * dm.heightPixels))
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /** Swipe fallback for custom feeds such as short-video/reels surfaces. */
    fun swipe(direction: String, durationMs: Long = 320): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val cx = w * 0.5f
        val cy = h * 0.52f
        val (sx, sy, ex, ey) = when (direction.lowercase()) {
            "up" -> listOf(cx, h * 0.78f, cx, h * 0.24f)
            "down" -> listOf(cx, h * 0.24f, cx, h * 0.78f)
            "left" -> listOf(w * 0.82f, cy, w * 0.18f, cy)
            "right" -> listOf(w * 0.18f, cy, w * 0.82f, cy)
            else -> return false
        }
        val path = Path().apply { moveTo(sx, sy); lineTo(ex, ey) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(120, 1500)))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun scroll(forward: Boolean): Boolean {
        val node = findScrollable(rootInActiveWindow)
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                     else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (node?.performAction(action) == true) return true
        // Apps like Reels/Shorts often expose no scrollable accessibility node.
        return swipe(if (forward) "up" else "down")
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    /** Takes a screenshot (Android 11+) and returns it as JPEG, or null. Must be called off the main thread. */
    @Suppress("NewApi")
    fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        var out: ByteArray? = null
        val latch = CountDownLatch(1)
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        result.hardwareBuffer.close()
                        if (bmp != null) out = Frames.toJpeg(bmp, 768, 70)
                    } catch (_: Exception) {
                    } finally { latch.countDown() }
                }
                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
        } catch (_: Exception) { latch.countDown() }
        latch.await(4, TimeUnit.SECONDS)
        return out
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
}
