package com.companion.ai

import android.app.Application

class CompanionApp : Application() {
    lateinit var engine: CompanionEngine

    override fun onCreate() {
        super.onCreate()
        instance = this
        engine = CompanionEngine(this)
    }

    companion object {
        lateinit var instance: CompanionApp
    }
}
