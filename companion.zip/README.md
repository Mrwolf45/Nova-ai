# Zoya 6.0 Android source

1. Upload the extracted project contents to the root of your GitHub repository (including `.github/workflows/build.yml`).
2. Open **Actions → Build Zoya APK → Run workflow**.
3. Download the `zoya-6.0-build` artifact after the workflow succeeds.
4. Install `app-debug.apk` only after checking signing compatibility with the APK already on your phone.

QwenCloud Singapore and Gemini backup API keys are entered inside Zoya's Setup screen. Never commit keys to GitHub.

For stable in-place updates, configure the same Android keystore used by the installed APK as GitHub Actions secrets. See `ZOYA_5_RELEASE_NOTES.txt` for exact secret names and platform limitations.


## Zoya 6.0 UI refresh
- Home is now an avatar-first companion screen with one primary voice action.
- Chat, phone tools, memories, and setup are separated from the home screen.
- Quick actions use a two-column tile layout to prevent horizontal button overflow.
- Qwen3.8 Omni Realtime is integrated as the primary live provider when a QwenCloud Singapore API key is saved. Gemini Live keys are the fallback provider when Qwen fails to connect. The Qwen adapter uses WebSocket audio, image frames, text events, and custom tool calls.


## AI provider setup
1. Create a QwenCloud API key in the Singapore region. Region-specific keys are required.
2. In Zoya → Setup, save the Qwen key. It becomes the primary live voice/vision provider.
3. Optionally save one or more Gemini Live keys as fallback.
4. Qwen realtime function calls are routed through the existing confirmation-aware phone tool router.
5. The app stores entered keys in app-private SharedPreferences. This is convenient but not equivalent to a secure backend; a determined attacker with device access can extract them. For a public production app, use a backend that issues short-lived client credentials.

Qwen's Singapore free quota is limited and temporary; check the QwenCloud pricing page before regular use.
