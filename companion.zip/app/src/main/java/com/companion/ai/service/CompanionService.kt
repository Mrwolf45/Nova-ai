package com.companion.ai.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.companion.ai.AppState
import com.companion.ai.CompanionApp
import com.companion.ai.MainActivity

/** Keeps the companion alive in the background (needed for the mic and proactive triggers). */
class CompanionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("companion", "Companion", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "companion")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zoya active hai")
            .setContentText("Tap karke app kholo")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        try {
            ServiceCompat.startForeground(
                this, 1, n,
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            )
        } catch (e: Exception) {
            AppState.log("Service start error: ${e.message}")
            stopSelf()
            return
        }
        AppState.active = true
        CompanionApp.instance.engine.triggers.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        CompanionApp.instance.engine.triggers.stop()
        AppState.active = false
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, CompanionService::class.java))
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, CompanionService::class.java))
        }
    }
}
