package com.companion.ai.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.companion.ai.AppState
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

/** Streams ~1 JPEG frame per second from the front/back camera, with optional live preview and face/smile detection. */
class CameraStreamer(
    private val ctx: Context,
    private val onFrame: (jpeg: ByteArray, hasFace: Boolean, smile: Float, eyesOpen: Float) -> Unit
) {
    private val exec = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    @Volatile private var last = 0L

    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build()
        )
    }

    fun bind(owner: LifecycleOwner, preview: PreviewView?, front: Boolean) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                p.unbindAll()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy ->
                    try { handle(proxy) } catch (_: Exception) { } finally { proxy.close() }
                }
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (preview != null) {
                    val pv = Preview.Builder().build()
                    pv.setSurfaceProvider(preview.surfaceProvider)
                    p.bindToLifecycle(owner, selector, pv, analysis)
                } else {
                    p.bindToLifecycle(owner, selector, analysis)
                }
            } catch (e: Exception) {
                AppState.log("Camera error: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun unbind() {
        try { provider?.unbindAll() } catch (_: Exception) { }
    }

    private fun handle(proxy: ImageProxy) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 1000) return
        last = now
        var bmp: Bitmap = proxy.toBitmap()
        val rot = proxy.imageInfo.rotationDegrees
        if (rot != 0) {
            val m = Matrix().apply { postRotate(rot.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val jpeg = Frames.toJpeg(bmp, 512, 60)
        var has = false
        var smile = 0f
        var eyes = 1f
        if (AppState.proactiveOn || AppState.running) {
            try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                faces.firstOrNull()?.let {
                    has = true
                    smile = it.smilingProbability ?: 0f
                    eyes = minOf(it.leftEyeOpenProbability ?: 1f, it.rightEyeOpenProbability ?: 1f)
                }
            } catch (_: Exception) { }
        }
        onFrame(jpeg, has, smile, eyes)
    }
}
